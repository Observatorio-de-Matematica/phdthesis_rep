function p = Phi(x)
    
    p = [-x(1) + x(1)^2;
        -x(1) - x(3)];
end


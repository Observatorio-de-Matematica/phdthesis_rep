function f = forcing(x)
    f = - x(2);
end